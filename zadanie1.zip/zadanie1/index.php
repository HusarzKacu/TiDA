<?php


include_once("autoloader.php");

$uczen1 = new \Web\Uczen("Simon","Herod");

$uczen1->ustawPesel("12345678910");
$uczen1->miejscowosc = "Radomsko";

$uczen1->wizytowka();

?>
<?php
namespace Web;
class Uczen{
        private $imie;
        private $nazwisko;
        private $pesel;
        public $miejscowosc;

        public function wizytowka(){
            echo "<br>Imię: ".$this->imie."<br>";
            echo "Nazwisko: ".$this->nazwisko."<br>";
            echo "PESEL: ".$this->pesel."<br>";
            echo "Miejscowość: ".$this->miejscowosc."<br>";
        }

        public function ustawPesel($pesel){
            $this->pesel = $pesel;
        }

        public function __construct($imie,$nazwisko){
            $this->imie = $imie;
            $this->nazwisko = $nazwisko;
        }
    }

?>